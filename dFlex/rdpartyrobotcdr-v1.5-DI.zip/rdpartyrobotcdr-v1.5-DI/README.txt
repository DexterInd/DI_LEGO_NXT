/*
 * $Id: README.txt 29 2010-06-25 12:55:41Z xander $
 */

-= Note =-
These drivers are for RobotC 2.00 and higher and are part of the
version 1.5 of the 3rd Party RobotC Drivers suite.


-= Changes in this version =-
Newly added: 
Drivers for Dexter Industries dFlex, dPressure and temp probe
Test program for Mindsensors Touch Sensor MUX with HiTechnic Sensor MUX
Driver for additional timers in ROBOTC

Documentation changes:
All drivers sorted by manufacturer for easy lookup

Deleted:
HTDIR, has been replaced by HTIRS2

Changes: 
HTIRL: inline functions have been removed, are now part of the calling functions.
HTIRS2-SMUX-test1.c: added check for SMUX power
mainpage.h: added groups for documentation modules


-= API Documentation =-
The complete API documentation can be found in the html folder.
Just point your browser at the index.html file.


-= Downloads and support =-
These drivers can also be downloaded from:
http://sourceforge.net/projects/rdpartyrobotcdr/

The documentation is hosted here:
http://rdpartyrobotcdr.sourceforge.net/documentation/index.html

For support questions, please use the RobotC 3rd party sensors forum:
http://www.robotc.net/forums/viewforum.php?f=41

Thanks,
Xander Soldaat (mightor@gmail.com)

/*
 * $Id: README.txt 29 2010-06-25 12:55:41Z xander $
 */