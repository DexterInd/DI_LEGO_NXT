#define NXTBEE_MASTER

#include "NXTBee-comms.h"

// int xscale(int x) - Scales x values from camera coordinates to screen coordinates.
int xscale(int x) {
  return ((x - 12) * 99) / 175;
}

// int yscale(int y) - Scales y values from camera coordinates to screen coordinates.
int yscale(int y) {
  return ((143 - y) * 63) / 143;
}


int getNumBlobs() {
  int numblobs = -1;
  memset(packet.request[0], 0, REQUESTLEN);
  packet.request[2] = NXTCAM_NUMBLOBS;
  if(NXTBeeXMIT()) {
    nxtDisplayTextLine(7, "NUMBLOBS: %d", packet.reply[2]);
    numblobs = packet.reply[2];
  } else {
    nxtDisplayTextLine(7, "NUMBLOBS failure");
  }
  return numblobs;
}

void getBlob(int index, int &x1, int &x2, int &y1, int &y2) {
  memset(packet.request[0], 0, REQUESTLEN);
  memset(packet.reply[0], 0, REPLYLEN);
  packet.request[2] = NXTCAM_GETBLOB;

  NXTBeeXMIT();

  index = (int)packet.reply[2];
  x1 = xscale(packet.reply[4] & 0x00FF);
  x2 = xscale(packet.reply[5] & 0x00FF);
  y1 = yscale(packet.reply[6] & 0x00FF);
  y2 = yscale(packet.reply[7] & 0x00FF);
}

task main () {
  int x1, x2, y1, y2;
  int numblobs = 0;
  int index = 0;

  while (true) {
    eraseDisplay();
    numblobs = getNumBlobs();
    for (int i = 0; i < numblobs; i++) {
      getBlob(index, x1, x2, y1, y2);
      nxtFillRect(x1, y1, x2, y2);
    }
    wait1Msec(100);
  }
}
