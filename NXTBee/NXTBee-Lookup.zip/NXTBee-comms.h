// nxtbee communications library

const int TIMEOUT = 50;
const int REQUESTLEN = 8;
const int REPLYLEN = 8;

const ubyte LIGHT_SENSOR_SET_ACTIVE   = 1;
const ubyte LIGHT_SENSOR_SET_INACTIVE = 2;
const ubyte NXTCAM_NUMBLOBS = 3;
const ubyte NXTCAM_GETBLOB = 4;


const ubyte crctable [256] = {
      0, 94, 188, 226, 97, 63, 221, 131, 194, 156,    //  10
      126, 32, 163, 253, 31, 65, 157, 195, 33, 127,   //  20
      252, 162, 64, 30, 95, 1, 227, 189, 62, 96,      //  30
      130, 220, 35, 125, 159, 193, 66, 28, 254, 160,  //  40
      225, 191, 93, 3, 128, 222, 60, 98, 190, 224,    //  50
      2, 92, 223, 129, 99, 61, 124, 34, 192, 158,     //  60
      29, 67, 161, 255, 70, 24, 250, 164, 39, 121,    //  70
      155, 197, 132, 218, 56, 102, 229, 187, 89, 7,   //  80
      219, 133, 103, 57, 186, 228, 6, 88, 25, 71,     //  90
      165, 251, 120, 38, 196, 154, 101, 59, 217, 135, // 100
      4, 90, 184, 230, 167, 249, 27, 69, 198, 152,    // 110
      122, 36, 248, 166, 68, 26, 153, 199, 37, 123,   // 120
      58, 100, 134, 216, 91, 5, 231, 185, 140, 210,   // 130
      48, 110, 237, 179, 81, 15, 78, 16, 242, 172,    // 140
      47, 113, 147, 205, 17, 79, 173, 243, 112, 46,   // 150
      204, 146, 211, 141, 111, 49, 178, 236, 14, 80,  // 160
      175, 241, 19, 77, 206, 144, 114, 44, 109, 51,   // 170
      209, 143, 12, 82, 176, 238, 50, 108, 142, 208,  // 180
      83, 13, 239, 177, 240, 174, 76, 18, 145, 207,   // 190
      45, 115, 202, 148, 118, 40, 171, 245, 23, 73,   // 200
      8, 86, 180, 234, 105, 55, 213, 139, 87, 9,      // 210
      235, 181, 54, 104, 138, 212, 149, 203, 41, 119, // 220
      244, 170, 72, 22, 233, 183, 85, 11, 136, 214,   // 230
      52, 106, 43, 117, 151, 201, 74, 20, 246, 168,   // 240
      116, 42, 200, 150, 21, 75, 169, 247, 182, 232,  // 250
      10, 84, 215, 137, 107, 53};                     // 256

typedef enum {
  XM_STATE_START = 0,
  XM_STATE_SENDING,
  XM_STATE_WAITREPLY1,
  XM_STATE_TIMEDOUT,
  XM_STATE_RESENDING,
  XM_STATE_WAITREPLY2,
  XM_STATE_FAILED,
  XM_STATE_READING,
  XM_STATE_SUCCESS
} tXmState;

typedef enum {
  XS_STATE_START = 0,
  XS_STATE_LISTENING,
  XS_STATE_WAITREQUEST,
  XS_STATE_TIMEDOUT,
  XS_STATE_FAILED,
  XS_STATE_READING,
  XS_STATE_PROCESSING,
  XS_STATE_SENDING,
  XS_STATE_DONE
} tXsState;

typedef ubyte tMessage[8];


// request[0] = CRC
// request[1] = src:dst
// request[2-7] = data
typedef struct {
  tMessage request[8];
  tMessage reply[8];
  ubyte replylen;
} tPacket;

tPacket packet;

tXmState XmState;

tXsState XsState;

ubyte calcCRC8(tMessage &msg);

#ifdef NXTBEE_SLAVE
void do_XS_STATE_START();
void do_XS_STATE_LISTENING();
void do_XS_STATE_WAITREQUEST();
void do_XS_STATE_TIMEDOUT();
void do_XS_STATE_FAILED();
void do_XS_STATE_READING();
void do_XS_STATE_PROCESSING();
void do_XS_STATE_SENDING();
void do_XS_STATE_DONE();
void slaveHandleRequest();
#endif

#ifdef  NXTBEE_MASTER
void do_XM_STATE_START();
void do_XM_STATE_SENDING();
void do_XM_STATE_WAITREPLY1();
void do_XM_STATE_TIMEDOUT();
void do_XM_STATE_RESENDING();
void do_XM_STATE_WAITREPLY2();
void do_XM_STATE_FAILED();
void do_XM_STATE_READING();
void do_XM_STATE_SUCCESS();
#endif


ubyte calcCRC8(tMessage &msg) {
  ubyte crc = 0;
  for (ubyte i = 1; i < 8; i++) {
    crc = crctable[crc ^ msg[i]];
  }
  return crc;
}

#ifdef  NXTBEE_MASTER
bool NXTBeeXMIT () {
  XmState = XM_STATE_START;

  while (true) {
    switch (XmState) {
      case XM_STATE_START:
          writeDebugStreamLine("XM_STATE_START");
          do_XM_STATE_START();
          break;
      case XM_STATE_SENDING:
          writeDebugStreamLine("XM_STATE_SENDING");
          do_XM_STATE_SENDING();
          break;
      case XM_STATE_WAITREPLY1:
          writeDebugStreamLine("XM_STATE_WAITREPLY1");
          do_XM_STATE_WAITREPLY1();
          break;
      case XM_STATE_READING:
          writeDebugStreamLine("XM_STATE_READING");
          do_XM_STATE_READING();
          break;
      case XM_STATE_TIMEDOUT:
          writeDebugStreamLine("XM_STATE_TIMEDOUT");
          do_XM_STATE_TIMEDOUT();
          break;
      case XM_STATE_RESENDING:
          writeDebugStreamLine("XM_STATE_RESENDING");
          do_XM_STATE_RESENDING();
          break;
      case XM_STATE_WAITREPLY2:
          writeDebugStreamLine("XM_STATE_WAITREPLY2");
          do_XM_STATE_WAITREPLY2();
          break;
      case XM_STATE_FAILED:
          writeDebugStreamLine("XM_STATE_FAILED");
          do_XM_STATE_FAILED();
          return false;
          break;
      case XM_STATE_SUCCESS:
          writeDebugStreamLine("XM_STATE_SUCCESS");
          do_XM_STATE_SUCCESS();
          return true;
    }
  }
}



void do_XM_STATE_START() {
  ubyte dummy[8];

  // clear out any remaining bytes from the buffers
  while (nxtGetAvailHSBytes() > 1) {
    nxtReadRawHS(dummy[0], 8);
  }

  packet.request[1] = 0;

  packet.replylen = REPLYLEN;
  memset(packet.reply[0], 0, 8);
  packet.request[0] = calcCRC8(packet.request[0]);

  XmState = XM_STATE_SENDING;
}

void do_XM_STATE_SENDING() {
  nxtWriteRawHS(packet.request[0], 8, 0);
  XmState = XM_STATE_WAITREPLY1;
}

void do_XM_STATE_WAITREPLY1() {
  time1[T1] = 0;
	while (nxtGetAvailHSBytes() < packet.replylen) {
	  if (time1[T1] > TIMEOUT) {
	    XmState = XM_STATE_TIMEDOUT;
	    return;
	  }
	}
	XmState = XM_STATE_READING;
}

void do_XM_STATE_TIMEDOUT() {
  PlaySound(soundBlip);
  while(bSoundActive) EndTimeSlice();

  XmState = XM_STATE_RESENDING;
}

void do_XM_STATE_RESENDING() {
  nxtWriteRawHS(packet.request[0], 8, 0);
  XmState = XM_STATE_WAITREPLY2;
}

void do_XM_STATE_WAITREPLY2() {
  time1[T1] = 0;
	while (nxtGetAvailHSBytes() < packet.replylen) {
	  if (time1[T1] > TIMEOUT) {
	    XmState = XM_STATE_FAILED;
	    return;
	  }
	}
	XmState = XM_STATE_READING;
}

void do_XM_STATE_FAILED() {
  PlaySound(soundDownwardTones);
  while(bSoundActive) EndTimeSlice();
}

// todo : checksum verification
void do_XM_STATE_READING() {
  nxtReadRawHS((ubyte)packet.reply[0], packet.replylen);

#ifdef NXTBEE_DEBUG_MASTER
  nxtDisplayTextLine(0, "0x%02x  0x%02x", packet.reply[0], packet.reply[1]);
	nxtDisplayTextLine(1, "0x%02x  0x%02x", packet.reply[2], packet.reply[3]);
	nxtDisplayTextLine(2, "0x%02x  0x%02x", packet.reply[4], packet.reply[5]);
	nxtDisplayTextLine(3, "0x%02x  0x%02x", packet.reply[6], packet.reply[7]);
#endif

	if (calcCRC8(packet.reply[0]) != packet.reply[0]) {
    XmState = XM_STATE_FAILED;
    return;
  }

  XmState = XM_STATE_SUCCESS;
}

void do_XM_STATE_SUCCESS() {
  //PlaySound(soundFastUpwardTones);
  //while(bSoundActive) EndTimeSlice();
}

#endif

#ifdef NXTBEE_SLAVE
void NXTBeeListen () {
  XsState = XS_STATE_START;

  while (true) {
    switch (XsState) {
      case XS_STATE_START:
          writeDebugStreamLine("XS_STATE_START");
          do_XS_STATE_START();
          break;
      case XS_STATE_LISTENING:
          writeDebugStreamLine("XS_STATE_LISTENING");
          do_XS_STATE_LISTENING();
          break;
      case XS_STATE_WAITREQUEST:
          writeDebugStreamLine("XS_STATE_WAITREQ");
          do_XS_STATE_WAITREQUEST();
          break;
      case XS_STATE_TIMEDOUT:
          writeDebugStreamLine("XS_STATE_TIMEDOUT");
          do_XS_STATE_TIMEDOUT();
          break;
      case XS_STATE_FAILED:
          writeDebugStreamLine("XS_STATE_FAILED");
          do_XS_STATE_FAILED();
          break;
      case XS_STATE_READING:
          writeDebugStreamLine("XS_STATE_READING");
          do_XS_STATE_READING();
          break;
      case XS_STATE_PROCESSING:
          writeDebugStreamLine("XS_STATE_PROC");
          do_XS_STATE_PROCESSING();
          break;
      case XS_STATE_SENDING:
          writeDebugStreamLine("XS_STATE_SENDING");
          do_XS_STATE_SENDING();
          break;
      case XS_STATE_DONE:
          writeDebugStreamLine("XS_STATE_DONE");
          do_XS_STATE_DONE();
          break;
    }
  }
}


void do_XS_STATE_START() {
  ubyte dummy[8];

  // clear out any remaining bytes from the buffers
  while (nxtGetAvailHSBytes() > 1) {
    nxtReadRawHS(dummy[0], 8);
  }

  XsState = XS_STATE_LISTENING;
}

void do_XS_STATE_LISTENING() {
	while (nxtGetAvailHSBytes() < 1)
    EndTimeSlice();

  XsState = XS_STATE_WAITREQUEST;
}

void do_XS_STATE_WAITREQUEST() {
  time1[T1] = 0;
	while (nxtGetAvailHSBytes() < 8) {
	  if (time1[T1] > TIMEOUT) {
	    XsState = XS_STATE_TIMEDOUT;
	    return;
	  }
	}
	XsState = XS_STATE_READING;
}

void do_XS_STATE_TIMEDOUT() {
  PlaySound(soundBlip);
  XsState = XS_STATE_FAILED;
}

void do_XS_STATE_FAILED() {
  ubyte dummy[8];

  PlaySound(soundDownwardTones);

  // clear out any remaining bytes from the buffers
  while (nxtGetAvailHSBytes() > 1) {
    nxtReadRawHS(dummy[0], 8);
    EndTimeSlice();
  }

  XsState = XS_STATE_DONE;
}

void do_XS_STATE_READING() {
  nxtReadRawHS((ubyte)packet.request[0], REQUESTLEN);
#ifdef NXTBEE_DEBUG_SLAVE
	nxtDisplayTextLine(0, "0x%02x  0x%02x", packet.request[0], packet.request[1]);
	nxtDisplayTextLine(1, "0x%02x  0x%02x", packet.request[2], packet.request[3]);
	nxtDisplayTextLine(2, "0x%02x  0x%02x", packet.request[4], packet.request[5]);
	nxtDisplayTextLine(3, "0x%02x  0x%02x", packet.request[6], packet.request[7]);
#endif
  XsState = XS_STATE_PROCESSING;
}

void do_XS_STATE_PROCESSING() {

  ubyte crc = calcCRC8(packet.request[0]);
  ubyte source = 0;
  ubyte destination = 0;

  if (crc != packet.request[0]) {
    nxtDisplayTextLine(5, "bad CRC: %d", crc);
    XsState = XS_STATE_FAILED;
    return;
  }

  slaveHandleRequest();

  XsState = XS_STATE_SENDING;
}

void do_XS_STATE_SENDING() {
  //memcpy(packet.reply[0], packet.request[0], REQUESTLEN);
  nxtWriteRawHS(packet.reply[0], 8, 0);
  XsState = XS_STATE_DONE;
}

void do_XS_STATE_DONE() {
  XsState = XS_STATE_LISTENING;
}

#endif
