It is done and allows for varied BAUD rates on enhanced firmware and at a fixed BAUD on standard.

I need to make it easier for you to know the baud rate, but see the contsants file. For a baud of 9600, the constant value is 5.

I will be renaming this later. You can guess where it came from! :)

Please use the firmware in the directory above.

Thanks!

Andy